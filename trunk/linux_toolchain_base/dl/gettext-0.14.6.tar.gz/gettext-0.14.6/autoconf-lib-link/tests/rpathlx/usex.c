extern int rpathx_value (void);
int main () { return !(rpathx_value () == 5); }
