#include "../../gettext-tools/lib/relocatable.c"
